import 'package:flutter/material.dart';
import 'package:control_pad/control_pad.dart';
import 'package:flutter_mjpeg/flutter_mjpeg.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

String URL = "http://192.168.43.117:3000/";
String URL_VIDEO = "http://192.168.43.117:8000/stream.mjpg";
String lastAction = "";
var video = Mjpeg(
  isLive: true,
  error: (context, error, stack) {
    print(error);
    print(stack);
    return Text("Can't open " + video.stream + "\n" + error.toString(), style: TextStyle(color: Colors.red));
  },
  stream: URL_VIDEO, //'http://192.168.1.37:8081',
);

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  static const String _title = 'Flutter Code Sample';

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: _title,
      debugShowCheckedModeBanner: false,
      home: MyStatefulWidget(),
    );
  }
}

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle = TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static List<Widget> _widgetOptions = <Widget>[
    Column(
      children: <Widget>[
        Container(
          child: video,
        ),
        Expanded(
            child: Center(
          child: ConstrainedBox(
              constraints: BoxConstraints.expand(height: 200, width: 300),
              child: JoystickView(
                  backgroundColor: Colors.red,
                  innerCircleColor: Colors.redAccent,
                  onDirectionChanged: (double x, double y) => {
                        handleChange(x, y)
                      })),
        )),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(50), // NEW
          ),
          onPressed: () {
            sendDirection("Horn");
          },
          child: const Text('Horn'),
        ),
      ],
    ),
    MyCustomForm()
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Controller'),
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Controller',
            backgroundColor: Colors.red,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business),
            label: 'Configuration',
            backgroundColor: Colors.green,
          ),
          /*  BottomNavigationBarItem(
            icon: Icon(Icons.school),
            label: 'School',
            backgroundColor: Colors.purple,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
            backgroundColor: Colors.pink,
          ),
        */
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}

handleChange(double x, double y) {
  String action = "";
  if (x == 0 && y == 0) {
    action = "stop";

    sendDirection(action);
  } else {
    if (y == 1) {
      print(y);
      if (x > 330 && x < 360 || x > 0 && x < 30) {
        action = "up";
      } else if (x > 60 && x < 120) {
        action = "right";
      } else if (x > 150 && x < 210) {
        action = "down";
      } else if (x > 240 && x < 300) {
        action = "left";
      }
      sendDirection(action);
    }
  }
}

void sendDirection(String action) {
  if (action != lastAction) {
    int x = 0, y = 0;
    switch (action) {
      case "up":
        y = -1;
        break;
      case "right":
        x = 1;
        break;
      case "down":
        y = 1;
        break;
      case "left":
        x = -1;
        break;
      case "Horn":
        x = -2;
        y = -2;
        break;
      case "stop":
        break;
    }
    http.post(
      Uri.parse(URL),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{
        'X': x.toString(),
        'Y': y.toString(),
      }),
    );
    lastAction = action;
  }
}

class MyCustomForm extends StatefulWidget {
  @override
  _MyCustomFormState createState() => _MyCustomFormState();
}

class _MyCustomFormState extends State<MyCustomForm> {
  final myController1 = TextEditingController();
  final myController2 = TextEditingController();

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    myController2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
      children: <Widget>[
        Container(
            margin: const EdgeInsets.only(top: 10.0),
            child: Material(
                color: Colors.white,
                child: Column(children: <Widget>[
                  Text(
                    'Stream URL:',
                  ),
                  Container(
                    color: Colors.white,
                    margin: const EdgeInsets.only(top: 1.0, left: 10, right: 10, bottom: 10),
                    child: TextFormField(
                      style: TextStyle(
                        fontSize: 16.0,
                        height: 1.0,
                        color: Colors.black,
                      ),
                      controller: myController1,
                      decoration: const InputDecoration(border: OutlineInputBorder()),
                    ),
                  ),
                  Text(
                    'Commands URL:',
                  ),
                  Container(
                    color: Colors.white,
                    margin: const EdgeInsets.only(top: 1.0, left: 10, right: 10, bottom: 10),
                    child: TextFormField(
                      style: TextStyle(
                        fontSize: 16.0,
                        height: 1.0,
                        color: Colors.black,
                      ),
                      controller: myController2,
                      decoration: const InputDecoration(border: OutlineInputBorder()),
                    ),
                  )
                ]))),
        Container(
            color: Colors.white,
            margin: const EdgeInsets.only(top: 1.0, left: 10, right: 10, bottom: 10),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50), // NEW
              ),
              onPressed: () {
                URL = (myController2.value.text);
                URL_VIDEO = myController1.value.text;

                video = Mjpeg(
                  isLive: true,
                  error: (context, error, stack) {
                    print(error);
                    print(stack);
                    return Text("Can't open " + video.stream + "\n" + error.toString(), style: TextStyle(color: Colors.red));
                  },
                  stream: URL_VIDEO, //'http://192.168.1.37:8081',
                );
              },
              child: const Text('Submit'),
            ))
      ],
    ));
  }
}
